<?php
#Inclui o rodapé nas páginas do sistema

echo '<br>';
echo '<!-- Footer -->';
echo '<footer class="text-center text-lg-start bg-light text-muted">';
echo '<!-- Copyright -->';
echo '<div class="text-center p-4">';
echo '© 2022 Copyright: ';
echo '<a class="text-reset fw-bold" href="https://foz.ifpr.edu.br" target="blank">IFPR (Campus Foz do Iguaçu)</a>';
echo '</div>';
echo '</footer>';


echo '<!-- JavaScript (Opcional) -->';
echo '<!-- jQuery primeiro, depois Popper.js, depois Bootstrap JS -->';
echo '<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>';
echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>';
echo '<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>';

?>