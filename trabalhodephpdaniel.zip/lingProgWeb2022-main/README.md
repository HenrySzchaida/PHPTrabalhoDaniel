<img src="https://reitoria.ifpr.edu.br/wp-content/uploads/2016/01/logo-IFPR.png" height="100%" align="right">

# Linguagem de Programação para Web (3º ano)
Repositório criado para disponibilização de materiais durante a disciplina de **Linguagem de Programação para Web** realizada no **ano de 2022** (3º e 4º bimestres).

## Informações

### Curso
* **Instituição**: Instituto Federal do Paraná - Campus Foz do Iguaçu
* **Curso**: Técnico em Desenvolvimento de Sistemas

### Disciplina
* **Professor**: Daniel Di Domenico
* **Carga horária**: 120 horas aula
* **Ano**: 2022

