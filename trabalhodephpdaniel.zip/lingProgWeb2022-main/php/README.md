### Como utilizar a aplicação cad_alunos_aula em sua máquina

* **1-**: Fazer download do diretório `cad_alunos_aula`
* **2-**: Caso não tenha a base de dados, criá-la utilizando o arquivo `script_base_alunos.sql` através do phpMyAdmin.
* **3-**: Verificar a conexão à base de dados no arquivo `util/conexao.php`, alterando as variáveis conforme necessário.

