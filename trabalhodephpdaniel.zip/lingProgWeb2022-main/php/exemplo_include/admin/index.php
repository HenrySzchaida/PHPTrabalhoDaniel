<?php include_once(__DIR__ . "/../inc/head.php"); ?>
<h1>Home do Administrador</h1>
<?php include_once(__DIR__ . "/../inc/footer.php"); ?>