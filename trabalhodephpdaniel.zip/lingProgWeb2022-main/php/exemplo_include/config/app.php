<?php

define("APP_NAME", "Minha aplicação");